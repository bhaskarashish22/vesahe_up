 <!-- CSS -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat%3A500%2C700%7CRoboto+Condensed:700%7CRoboto%3A700&amp;display=swap" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="<?=$urlroot;?>css/white-line-awesome.css">
	
	<link type="text/css" rel="stylesheet" href="<?=$urlroot;?>css/white-style.css">
	
	<link type="text/css" rel="stylesheet" href="<?=$urlroot;?>css/responsive.css">

	<!-- Icon -->
	<link rel="icon" href="<?=$urlroot;?>img/favicon.png" sizes="32x32" />
    
    <style type="text/css">
	
div.pagination {	padding: 3px;	margin: 3px;} div.pagination a {	margin: 0 3px;
    padding: 8px 16px;	border: 2px solid #4D4641;		text-decoration: none; /* no underline */	color: #fff;}div.pagination a:hover, div.pagination a:active {	border: 2px solid #ecc731;	color: #fff;}div.pagination span.current {	 padding: 8px 16px;	margin: 2px;		border: 2px solid #ecc731;			font-weight: bold;		background-color: #fff;		color: #26211d;	}	div.pagination span.disabled {		padding: 8px 16px;		margin: 2px;		border: 2px solid #4D4641;		color: #fff;	}

.works-img
	{
	width:100%;
	height:418px;
		
	}

@media only screen and (min-width: 220px) and (max-width: 768px) {

.works-img
	{
	width:100%;
	height:auto;	
	}
	

}

	
	</style>